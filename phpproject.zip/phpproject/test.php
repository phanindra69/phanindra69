<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<video width="320" height="240" controls autoplay>
  <source src="alita.mp4" type="video/mp4">
  Sorry, your browser doesn't support the video element.
</video>
</body>
</html>
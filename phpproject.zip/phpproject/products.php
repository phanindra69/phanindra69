<?php
require("includes/common.php");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Twix|movie</title>
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
    </head>

    <body>
        <?php
        include 'includes/header.php';
;
        ?>
        <div class="container" id="content">
         
            <div class="jumbotron home-spacer" id="products-jumbotron">
                <h1><center>Welcome to Twix</center></h1>
              
            </div>
          

           <video width="1150" controls>
            <source src="C:\xampp\htdocs\phpproject\movie\alita.mp4" type="video/mp4">
           </video>

        </div>

        <?php include("includes/footer.php"); ?>
    </body>

</html>

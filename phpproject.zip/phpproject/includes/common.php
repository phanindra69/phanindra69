<?php
$con = mysqli_connect("localhost:3301", "root", "", "twix")or die($mysqli_error($con));
session_start();
